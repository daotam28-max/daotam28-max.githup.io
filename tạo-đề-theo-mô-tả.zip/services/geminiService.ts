import { GoogleGenAI, Type } from "@google/genai";
import { ExamConfig, GenerationMode, ExamVariant } from "../types";

export const generateSingleVariant = async (config: ExamConfig, variantIndex: number): Promise<ExamVariant> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key chưa được cấu hình.");
  }

  const ai = new GoogleGenAI({ apiKey });

  let promptDetail = "";
  let parts: any[] = [];

  // Base prompt focused on a SINGLE variant
  let basePrompt = `Hãy tạo ĐỀ THI SỐ ${variantIndex} (trong bộ ${config.numberOfVariants} đề).
  - Môn học: ${config.subject}
  - Trình độ: ${config.grade}
  - Loại bài kiểm tra: ${config.examType}
  - Mức độ khó chung: ${config.difficultyLevel}`;

  // Add selected topics if available
  if (config.selectedTopics && config.selectedTopics.length > 0) {
      basePrompt += `\n- NỘI DUNG TRỌNG TÂM CẦN KIỂM TRA: ${config.selectedTopics.join(", ")}. Hãy tập trung phần lớn câu hỏi vào các chủ đề này.`;
  }
  
  basePrompt += `\n\nQUAN TRỌNG: Đây là đề thứ ${variantIndex}. Hãy thay đổi số liệu, nội dung câu hỏi hoặc ngữ cảnh để đảm bảo nó KHÁC BIỆT so với các đề khác, nhưng vẫn giữ nguyên cấu trúc và độ khó.`;

  if (config.mode === GenerationMode.DESCRIPTION) {
    promptDetail = `Yêu cầu chi tiết bổ sung: "${config.description}"`;
    parts.push({ text: `${basePrompt}\n${promptDetail}` });
  } else if (config.mode === GenerationMode.STRUCTURE) {
    promptDetail = `Cấu trúc đề thi (số lượng câu hỏi):
    - Nhận biết (Dễ): ${config.structure.easy} câu
    - Thông hiểu (TB): ${config.structure.medium} câu
    - Vận dụng (Khó): ${config.structure.hard} câu
    - Vận dụng cao (Rất khó): ${config.structure.veryHard} câu
    
    Lưu ý: Tuân thủ mức độ khó chung là "${config.difficultyLevel}" khi biên soạn nội dung từng câu hỏi.`;
    parts.push({ text: `${basePrompt}\n${promptDetail}` });
  } else if (config.mode === GenerationMode.OFFICIAL_7991) {
    // Read the user-defined structure
    const s7991 = config.structure7991;
    
    promptDetail = `TUÂN THỦ CẤU TRÚC CÔNG VĂN 7991 (4 Phần):
    
    1. PHẦN I: Trắc nghiệm nhiều lựa chọn (${s7991.part1} Câu).
       - Mỗi câu hỏi có 4 phương án A, B, C, D. Chọn 01 phương án đúng.
    
    2. PHẦN II: Trắc nghiệm Đúng/Sai (${s7991.part2} Câu).
       - Mỗi câu hỏi có 4 ý con a), b), c), d).
       - Học sinh phải trả lời Đúng hoặc Sai cho từng ý.
    
    3. PHẦN III: Trắc nghiệm trả lời ngắn (${s7991.part3} Câu).
       - Học sinh trả lời bằng số hoặc chuỗi ký tự ngắn (tối đa 4 ký tự).
    
    4. PHẦN IV: Tự luận (${s7991.part4} Câu).
       - Trình bày lời giải chi tiết (Nếu số lượng là 0 thì bỏ qua phần này).

    Chủ đề kiến thức bổ sung: "${config.description || config.subject}"`;
    parts.push({ text: `${basePrompt}\n${promptDetail}` });

  } else if (config.mode === GenerationMode.SAMPLE) {
    promptDetail = `Dựa vào tài liệu mẫu, hãy tạo ra đề thi mới tương tự (thay đổi số liệu/câu hỏi). Hãy điều chỉnh độ khó về mức: ${config.difficultyLevel}.`;
    
    let fullTextPrompt = `${basePrompt}\n${promptDetail}`;
    if (config.sampleContent) {
        fullTextPrompt += `\n--- NỘI DUNG VĂN BẢN ĐÍNH KÈM ---\n${config.sampleContent}`;
    }

    if (config.uploadedFile) {
        // Add instruction about the file
        fullTextPrompt += `\n\n[LƯU Ý]: Tôi có tải lên một tệp đính kèm (Hình ảnh/PDF). Hãy phân tích kỹ nội dung trong tệp này (câu hỏi, hình vẽ, cấu trúc) để tạo ra đề thi mới tương tự.`;
    }

    parts.push({ text: fullTextPrompt });

    if (config.uploadedFile) {
        parts.push({
            inlineData: {
                data: config.uploadedFile.data,
                mimeType: config.uploadedFile.mimeType
            }
        });
    }
  }

  // --- Handle Supplementary Files (Matrix and Reference) ---
  // These are appended to ALL modes to guide the AI
  
  if (config.matrixFile) {
      parts.push({ text: "\n\n--- MA TRẬN / ĐẶC TẢ ĐỀ THI ---\nVui lòng bám sát cấu trúc, phân bổ kiến thức và mức độ nhận thức trong file ma trận dưới đây:" });
      parts.push({
          inlineData: {
              data: config.matrixFile.data,
              mimeType: config.matrixFile.mimeType
          }
      });
  }

  if (config.referenceFile) {
      parts.push({ text: "\n\n--- TÀI LIỆU THAM KHẢO / SÁCH GIÁO KHOA ---\nSử dụng các ngữ liệu, phong cách diễn đạt hoặc kiến thức từ tài liệu tham khảo dưới đây để ra đề sát với chương trình học:" });
      parts.push({
          inlineData: {
              data: config.referenceFile.data,
              mimeType: config.referenceFile.mimeType
          }
      });
  }


  const systemInstruction = `Bạn là chuyên gia soạn đề thi giáo dục. Nhiệm vụ: Tạo 01 đề thi hoàn chỉnh VÀ LỜI GIẢI CHI TIẾT.

  YÊU CẦU VỀ FORMAT VÀ CỠ CHỮ:
  1. LaTeX Code:
     - Sử dụng document class 14pt: \\documentclass[14pt]{extarticle}
     - Nếu là mode OFFICIAL_7991, hãy phân chia rõ ràng các phần: \\section*{PHẦN I...}, \\section*{PHẦN II...}.
  
  2. HTML Structure (Quan trọng để hiển thị đẹp):
     - Bao quanh mỗi câu hỏi đề bài bằng: <div class="question-box">...</div>
     - Tiêu đề đề thi dùng <h1>, tiêu đề phần dùng <h2> (Ví dụ: <h2>PHẦN I. TRẮC NGHIỆM...</h2>).
     
     * ĐẶC BIỆT CHO MODE OFFICIAL_7991:
       - Phần II (Đúng/Sai): Sử dụng bảng cho các ý a,b,c,d.
         <div class="tf-question-container">
            <p><strong>Câu 1:</strong> Nội dung câu hỏi...</p>
            <table class="tf-table">
               <tr><td>a) Phát biểu 1...</td></tr>
               <tr><td>b) Phát biểu 2...</td></tr>
               ...
            </table>
         </div>
       - Phần III (Trả lời ngắn):
         <div class="short-answer-box">
             <strong>Câu 1:</strong> Nội dung... 
             <div class="answer-input-placeholder">[Điền đáp án...]</div>
         </div>

     - Trắc nghiệm thường (Phần I): <div class="options-grid"><div>A...</div>...</div>
     
  3. HÌNH VẼ MINH HỌA (BẮT BUỘC NẾU CẦN THIẾT):
     - Nếu câu hỏi liên quan đến Hình học, Đồ thị hàm số, Mạch điện, hoặc sơ đồ sinh học: BẠN PHẢI SINH MÃ SVG.
     - Đặt mã SVG trong thẻ: <div class="diagram-container"><svg ...>...</svg><div class="diagram-caption">Hình minh họa</div></div>
     - Đảm bảo SVG có width="300" height="auto" và viewbox hợp lý để hiển thị rõ ràng.

  4. PHẦN LỜI GIẢI CHI TIẾT (BẮT BUỘC):
     - Ở cuối đề thi, phải có phần "HƯỚNG DẪN GIẢI CHI TIẾT".
     - Trong HTML: Bao quanh toàn bộ phần giải bằng <div class="solution-section"><h2>HƯỚNG DẪN GIẢI CHI TIẾT</h2> ... </div>.
     - Với Phần II (Đúng/Sai), lời giải cần ghi rõ: Ý a: ĐÚNG - Giải thích...; Ý b: SAI - Giải thích...

  5. TOÁN HỌC:
     - Dùng $...$ và $$...$$.

  Trả về JSON object:
  {
    "latexCode": "Mã nguồn LaTeX đầy đủ (bao gồm cả đề và lời giải).",
    "htmlContent": "Mã HTML (bao gồm cả đề và phần <div class='solution-section'>...</div>)."
  }`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          role: "user",
          parts: parts,
        },
      ],
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7, 
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            latexCode: {
                type: Type.STRING,
                description: "Complete compilable LaTeX source code with 14pt font class",
            },
            htmlContent: {
                type: Type.STRING,
                description: "HTML content formatted with div.question-box and div.solution-section and svg diagrams",
            },
          },
          required: ["latexCode", "htmlContent"],
        },
      },
    });

    const result = JSON.parse(response.text || "{}");
    
    let latex = result.latexCode || "";
    if (latex.startsWith("```latex")) latex = latex.replace(/^```latex/, "").replace(/```$/, "");
    
    return {
        latexCode: latex.trim(),
        htmlContent: (result.htmlContent || "").trim()
    };

  } catch (error) {
    console.error(`Gemini API Error (Variant ${variantIndex}):`, error);
    throw new Error(`Lỗi khi tạo đề số ${variantIndex}.`);
  }
};