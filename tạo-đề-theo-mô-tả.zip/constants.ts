import { DifficultyLevel, DifficultyStructure, ExamConfig, ExamType, GenerationMode, Grade, Structure7991, Subject } from "./types";

export const DEFAULT_STRUCTURE: DifficultyStructure = {
  easy: 4,
  medium: 3,
  hard: 2,
  veryHard: 1,
};

export const DEFAULT_STRUCTURE_7991: Structure7991 = {
  part1: 12, // 12 câu trắc nghiệm nhiều lựa chọn
  part2: 2,  // 2 câu trắc nghiệm đúng sai
  part3: 4,  // 4 câu trắc nghiệm trả lời ngắn
  part4: 3   // 3 câu tự luận
};

export const DEFAULT_CONFIG: ExamConfig = {
  subject: Subject.MATH,
  grade: Grade.GRADE_12,
  examType: ExamType.FINAL_TERM_HK1,
  difficultyLevel: DifficultyLevel.MEDIUM,
  mode: GenerationMode.DESCRIPTION,
  description: "",
  structure: DEFAULT_STRUCTURE,
  structure7991: DEFAULT_STRUCTURE_7991,
  sampleContent: "",
  uploadedFile: null,
  matrixFile: null,
  referenceFile: null,
  numberOfVariants: 1,
  selectedTopics: [],
};

export const SUBJECT_OPTIONS = Object.values(Subject);
export const GRADE_OPTIONS = Object.values(Grade);
export const EXAM_TYPE_OPTIONS = Object.values(ExamType);
export const DIFFICULTY_OPTIONS = Object.values(DifficultyLevel);

// Dữ liệu giả lập chương trình học (Có thể mở rộng thêm)
export const CURRICULUM_TOPICS: Record<string, Record<string, string[]>> = {
  [Subject.MATH]: {
    [Grade.GRADE_12]: [
      "Ứng dụng đạo hàm để khảo sát hàm số",
      "Hàm số lũy thừa, Hàm số mũ và Hàm số logarit",
      "Nguyên hàm - Tích phân và ứng dụng",
      "Số phức",
      "Khối đa diện",
      "Mặt nón, Mặt trụ, Mặt cầu",
      "Phương pháp tọa độ trong không gian (Oxyz)"
    ],
    [Grade.GRADE_11]: [
      "Hàm số lượng giác và Phương trình lượng giác",
      "Dãy số - Cấp số cộng - Cấp số nhân",
      "Giới hạn. Hàm số liên tục",
      "Đạo hàm",
      "Đường thẳng và mặt phẳng trong không gian. Quan hệ song song",
      "Vectơ trong không gian. Quan hệ vuông góc"
    ],
    [Grade.GRADE_10]: [
      "Mệnh đề và Tập hợp",
      "Bất phương trình và Hệ bất phương trình bậc nhất hai ẩn",
      "Hàm số bậc hai và Đồ thị",
      "Hệ thức lượng trong tam giác",
      "Vectơ",
      "Thống kê",
      "Phương pháp tọa độ trong mặt phẳng (Oxy)"
    ]
  },
  [Subject.PHYSICS]: {
    [Grade.GRADE_12]: [
      "Dao động cơ",
      "Sóng cơ và sóng âm",
      "Dòng điện xoay chiều",
      "Dao động và sóng điện từ",
      "Sóng ánh sáng",
      "Lượng tử ánh sáng",
      "Hạt nhân nguyên tử"
    ],
    [Grade.GRADE_11]: [
      "Điện tích. Điện trường",
      "Dòng điện không đổi",
      "Dòng điện trong các môi trường",
      "Từ trường",
      "Cảm ứng điện từ",
      "Khúc xạ ánh sáng",
      "Mắt và các dụng cụ quang"
    ]
  },
  [Subject.CHEMISTRY]: {
    [Grade.GRADE_12]: [
      "Este - Lipit",
      "Cacbohidrat",
      "Amin, Amino axit và Protein",
      "Polime và vật liệu polime",
      "Đại cương về kim loại",
      "Kim loại kiềm, kiềm thổ, nhôm",
      "Sắt và một số kim loại quan trọng",
      "Phân biệt một số chất vô cơ"
    ],
    [Grade.GRADE_11]: [
      "Sự điện li",
      "Nitơ - Photpho",
      "Cacbon - Silic",
      "Đại cương về hóa học hữu cơ",
      "Hidrocacbon no",
      "Hidrocacbon không no",
      "Hidrocacbon thơm",
      "Ancol - Phenol",
      "Andehit - Xeton - Axit cacboxylic"
    ]
  },
  [Subject.ENGLISH]: {
    [Grade.GRADE_12]: [
      "Unit 1: Life Stories",
      "Unit 2: Urbanisation",
      "Unit 3: Green Living",
      "Unit 4: The Mass Media",
      "Unit 5: Cultural Identity",
      "Tenses (Review)",
      "Passive Voice",
      "Reported Speech",
      "Conditional Sentences",
      "Relative Clauses"
    ],
     [Grade.GRADE_10]: [
      "Unit 1: Family Life",
      "Unit 2: Humans and the Environment",
      "Unit 3: Music",
      "Unit 4: For a Better Community",
      "Unit 5: Inventions",
      "Present Simple vs Present Continuous",
      "Past Simple vs Past Continuous",
      "Future forms",
      "Gerunds and Infinitives"
    ]
  },
  [Subject.LITERATURE]: {
    [Grade.GRADE_12]: [
      "Tuyên ngôn Độc lập (Hồ Chí Minh)",
      "Tây Tiến (Quang Dũng)",
      "Việt Bắc (Tố Hữu)",
      "Đất Nước (Nguyễn Khoa Điềm)",
      "Sóng (Xuân Quỳnh)",
      "Người lái đò Sông Đà (Nguyễn Tuân)",
      "Ai đã đặt tên cho dòng sông? (Hoàng Phủ Ngọc Tường)",
      "Vợ chồng A Phủ (Tô Hoài)",
      "Vợ nhặt (Kim Lân)",
      "Rừng xà nu (Nguyễn Trung Thành)",
      "Chiếc thuyền ngoài xa (Nguyễn Minh Châu)",
      "Hồn Trương Ba, da hàng thịt (Lưu Quang Vũ)"
    ]
  }
};

// Fallback generic topics
export const GENERIC_TOPICS = [
  "Chương 1: Mở đầu",
  "Chương 2: Kiến thức cơ sở",
  "Chương 3: Các định luật/quy tắc",
  "Chương 4: Ứng dụng thực tế",
  "Chương 5: Tổng hợp và nâng cao"
];