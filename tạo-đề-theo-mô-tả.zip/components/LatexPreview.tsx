import React, { useState, useEffect, useRef } from "react";
import { ExamVariant } from "../types";
import DrawingModal from "./DrawingModal";

interface LatexPreviewProps {
  latexCode: string;
  htmlContent: string;
  variants?: ExamVariant[]; // Optional to support legacy prop usage or array usage
  isEditable?: boolean; // New prop to control edit permission
}

const LatexPreview: React.FC<LatexPreviewProps> = ({ latexCode: initialLatex, htmlContent: initialHtml, variants = [], isEditable = false }) => {
  const [activeTab, setActiveTab] = useState<'preview' | 'latex'>('preview');
  const [currentVariantIndex, setCurrentVariantIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const [isDrawingOpen, setIsDrawingOpen] = useState(false);
  
  // Local state for the HTML to display, allowing modification (shuffling, drawing insertion)
  const [displayedHtml, setDisplayedHtml] = useState<string>("");
  // Local state for LaTeX code to allow editing
  const [localLatexCode, setLocalLatexCode] = useState<string>("");
  
  const previewRef = useRef<HTMLDivElement>(null);

  // Normalize data: use variants array if available, otherwise fallback to single props
  const currentVariant = variants.length > 0 ? variants[currentVariantIndex] : { latexCode: initialLatex, htmlContent: initialHtml };
  const { latexCode } = currentVariant; 

  // Reset variant index when variants array changes significantly
  useEffect(() => {
    if (variants.length > 0) {
        if (currentVariantIndex >= variants.length) {
            setCurrentVariantIndex(0);
        }
    }
  }, [variants.length]);

  // Sync displayedHtml and localLatexCode when variant changes
  useEffect(() => {
    setDisplayedHtml(currentVariant.htmlContent);
    setLocalLatexCode(currentVariant.latexCode);
  }, [currentVariant.htmlContent, currentVariant.latexCode, currentVariantIndex]);

  // Render Math using KaTeX whenever displayedHtml, activeTab, or currentVariant changes
  useEffect(() => {
    if (activeTab === 'preview' && previewRef.current && (window as any).renderMathInElement) {
      setTimeout(() => {
        if (document.compatMode === 'BackCompat') {
            try {
                Object.defineProperty(document, 'compatMode', {
                    value: 'CSS1Compat',
                    configurable: true,
                    writable: true
                });
            } catch(e) {
                console.warn("Could not patch compatMode for KaTeX. Rendering might fail.", e);
            }
        }

        try {
          (window as any).renderMathInElement(previewRef.current, {
            delimiters: [
              { left: "$$", right: "$$", display: true },
              { left: "$", right: "$", display: false },
              { left: "\\(", right: "\\)", display: false },
              { left: "\\[", right: "\\]", display: true }
            ],
            throwOnError: false,
            strict: false,
            trust: true
          });
        } catch (e) {
          console.error("KaTeX rendering error:", e);
        }
      }, 100);
    }
  }, [displayedHtml, activeTab, currentVariantIndex]);

  const handleShuffle = () => {
    if (!displayedHtml) return;

    const parser = new DOMParser();
    const doc = parser.parseFromString(displayedHtml, 'text/html');

    // 1. Shuffle Options within .options-grid
    const optionGrids = doc.querySelectorAll('.options-grid');
    optionGrids.forEach(grid => {
        const options = Array.from(grid.children);
        // Fisher-Yates shuffle
        for (let i = options.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            grid.appendChild(options[j]); 
        }
    });

    // 2. Shuffle Questions (contiguous blocks of question-box, etc.)
    const questionClasses = ['.question-box', '.tf-question-container', '.short-answer-box'];
    const selector = questionClasses.join(', ');
    
    // Find all parents that contain at least one question
    const parents = new Set<Element>();
    doc.querySelectorAll(selector).forEach(el => {
        if (el.parentElement) parents.add(el.parentElement);
    });

    parents.forEach(parent => {
        const children = Array.from(parent.children);
        let block: Element[] = [];
        
        const isQuestion = (el: Element) => questionClasses.some(cls => el.matches(cls));

        const shuffleAndApply = (nodes: Element[]) => {
            if (nodes.length < 2) return;
            // Get reference for insertion (next sibling of the last node in block)
            const lastNode = nodes[nodes.length - 1];
            const nextSibling = lastNode.nextSibling;
            
            // Shuffle
            const shuffled = [...nodes].sort(() => Math.random() - 0.5);
            
            // Re-insert
            shuffled.forEach(node => {
                parent.insertBefore(node, nextSibling);
            });
        };

        children.forEach(child => {
            if (isQuestion(child)) {
                block.push(child);
            } else {
                if (block.length > 0) {
                    shuffleAndApply(block);
                    block = [];
                }
            }
        });
        if (block.length > 0) shuffleAndApply(block);
    });

    setDisplayedHtml(doc.body.innerHTML);
  };

  const handleInsertDrawing = (dataUrl: string) => {
      // Append the drawn image to the end of the exam
      // Note: Ideally we would insert at cursor, but for MVP appending is safest
      const imgHtml = `
        <div class="diagram-container">
            <img src="${dataUrl}" class="hand-drawn-image" alt="Hình vẽ tay" />
            <div class="diagram-caption">Hình vẽ bổ sung</div>
        </div>
      `;
      setDisplayedHtml(prev => prev + imgHtml);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(localLatexCode); // Copy updated code
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrintPDF = () => {
    setActiveTab('preview');
    setTimeout(() => {
        window.print();
    }, 300);
  };

  const handleDownloadWord = () => {
    let styles = "";
    const styleTags = document.querySelectorAll('style');
    styleTags.forEach(tag => {
        styles += tag.innerHTML;
    });

    styles += `
        @page { size: A4; margin: 2.54cm; }
        .question-box { border: 1px solid #000; padding: 10px; margin-bottom: 15px; }
        .diagram-container { text-align: center; margin: 10px 0; }
        .hand-drawn-image { max-width: 80%; height: auto; border: 1px dashed #ccc; }
        table { border-collapse: collapse; width: 100%; }
        td, th { border: 1px solid #ddd; padding: 8px; }
    `;

    const header = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' 
            xmlns:w='urn:schemas-microsoft-com:office:word' 
            xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <meta charset='utf-8'>
        <title>Exam Export</title>
        <style>${styles}</style>
      </head>
      <body>
        <div class="paper-sheet">
    `;
    const footer = "</div></body></html>";
    
    // Use displayedHtml (which might be shuffled) instead of htmlContent
    const sourceHTML = header + displayedHtml + footer;

    const blob = new Blob(['\ufeff', sourceHTML], {
        type: 'application/msword'
    });

    const url = URL.createObjectURL(blob);
    const element = document.createElement("a");
    element.href = url;
    element.download = `Exam_Paper_${currentVariantIndex + 1}.doc`;
    document.body.appendChild(element);
    element.click();
    
    document.body.removeChild(element);
    URL.revokeObjectURL(url);
  };

  if (!localLatexCode && !displayedHtml) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-slate-400 p-8 text-center bg-white/40 backdrop-blur-sm">
        <div className="bg-white p-6 rounded-full shadow-lg mb-4">
             <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1}
                stroke="currentColor"
                className="w-16 h-16 text-indigo-200"
            >
                <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"
                />
            </svg>
        </div>
        <p className="text-xl font-bold text-slate-600">Sẵn sàng tạo đề</p>
        <p className="text-sm text-slate-500 max-w-xs mt-2">Cấu hình bên trái và nhấn nút Tạo để AI bắt đầu soạn đề thi.</p>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Top Bar with Variant Selector & Toolbar */}
      <div className="flex flex-col border-b border-white/50 bg-white/60 backdrop-blur-md shadow-sm z-10">
          
          {/* Variant Selector Tabs */}
          {variants.length > 1 && (
            <div className="flex px-4 pt-4 space-x-2 overflow-x-auto custom-scrollbar">
                {variants.map((_, idx) => (
                    <button
                        key={idx}
                        onClick={() => setCurrentVariantIndex(idx)}
                        className={`px-4 py-2 text-sm font-bold border-b-2 transition-all whitespace-nowrap rounded-t-lg ${
                            currentVariantIndex === idx 
                            ? 'border-blue-600 text-blue-700 bg-blue-50/80' 
                            : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-white/50'
                        }`}
                    >
                        Mã đề {idx + 1}
                    </button>
                ))}
            </div>
          )}

          {/* Action Toolbar */}
          <div className="flex items-center justify-between p-3 px-4">
            <div className="flex p-1 bg-slate-200/50 rounded-lg">
              <button
                onClick={() => setActiveTab('preview')}
                className={`px-4 py-1.5 text-xs font-bold uppercase tracking-wider rounded-md transition-all ${
                  activeTab === 'preview'
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Xem trước
              </button>
              
              {/* Chỉ Admin (isEditable) mới nhìn thấy Tab Code */}
              {isEditable && (
                <button
                    onClick={() => setActiveTab('latex')}
                    className={`px-4 py-1.5 text-xs font-bold uppercase tracking-wider rounded-md transition-all ${
                    activeTab === 'latex'
                        ? 'bg-white text-blue-600 shadow-sm'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                >
                    LaTeX Code
                </button>
              )}
            </div>

            <div className="flex space-x-2">
               {activeTab === 'preview' && (
                <button
                    onClick={() => setIsDrawingOpen(true)}
                    className="flex items-center px-3 py-1.5 text-xs font-bold text-purple-700 bg-white border border-slate-200 hover:bg-purple-50 hover:text-purple-800 hover:border-purple-200 rounded-lg shadow-sm transition-all"
                    title="Vẽ hình minh họa"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1.5">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125" />
                    </svg>
                    Vẽ hình
                </button>
              )}

              {activeTab === 'preview' && (
                <button
                    onClick={handleShuffle}
                    className="flex items-center px-3 py-1.5 text-xs font-bold text-amber-700 bg-white border border-slate-200 hover:bg-amber-50 hover:text-amber-800 hover:border-amber-200 rounded-lg shadow-sm transition-all"
                    title="Đảo thứ tự câu hỏi và đáp án"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1.5">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 12c0-1.232-.046-2.453-.138-3.662a4.006 4.006 0 00-3.7-3.7 48.678 48.678 0 00-7.324 0 4.006 4.006 0 00-3.7 3.7c-.017.22-.032.441-.046.662M19.5 12l3-3m-3 3l-3-3m-12 3c0 1.232.046 2.453.138 3.662a4.006 4.006 0 003.7 3.7 48.656 48.656 0 007.324 0 4.006 4.006 0 003.7-3.7c.017-.22.032-.441.046-.662M4.5 12l3 3m-3-3l-3 3" />
                    </svg>
                    Đảo đề
                </button>
              )}

              <button
                 onClick={handleDownloadWord}
                 className="flex items-center px-3 py-1.5 text-xs font-bold text-slate-700 bg-white border border-slate-200 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-200 rounded-lg shadow-sm transition-all group"
                 title="Tải file Word (.doc)"
              >
                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 mr-1.5 text-blue-600 group-hover:scale-110 transition-transform">
                   <path d="M5.625 1.5c-1.036 0-1.875.84-1.875 1.875v17.25c0 1.035.84 1.875 1.875 1.875h12.75c1.035 0 1.875-.84 1.875-1.875V12.75A3.75 3.75 0 0016.5 9h-1.875a1.875 1.875 0 01-1.875-1.875V5.25A3.75 3.75 0 009 1.5H5.625z" />
                   <path d="M12.971 1.816A5.23 5.23 0 0114.25 5.25v1.875c0 .207.168.375.375.375H16.5a5.23 5.23 0 013.434 1.279 9.768 9.768 0 00-6.963-6.963z" />
                 </svg>
                 Word
              </button>

              <button
                onClick={handlePrintPDF}
                className="flex items-center px-3 py-1.5 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-lg shadow-red-500/20 transition-all"
                title="Lưu dưới dạng PDF"
              >
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 mr-1.5">
                    <path fillRule="evenodd" d="M5.625 1.5c-1.036 0-1.875.84-1.875 1.875v17.25c0 1.035.84 1.875 1.875 1.875h12.75c1.035 0 1.875-.84 1.875-1.875V12.75A3.75 3.75 0 0016.5 9h-1.875a1.875 1.875 0 01-1.875-1.875V5.25A3.75 3.75 0 009 1.5H5.625zM7.5 15a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5A.75.75 0 017.5 15zm.75 2.25a.75.75 0 000 1.5H12a.75.75 0 000-1.5H8.25z" clipRule="evenodd" />
                    <path d="M12.971 1.816A5.23 5.23 0 0114.25 5.25v1.875c0 .207.168.375.375.375H16.5a5.23 5.23 0 013.434 1.279 9.768 9.768 0 00-6.963-6.963z" />
                </svg>
                PDF
              </button>
              
               {/* Chỉ Admin mới thấy nút Copy Code */}
               {isEditable && (
                <button
                    onClick={handleCopy}
                    className="flex items-center px-3 py-1.5 text-xs font-bold text-slate-700 bg-white border border-slate-200 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-200 rounded-lg shadow-sm transition-all"
                    title="Sao chép mã nguồn LaTeX"
                >
                    {copied ? (
                    <span className="text-emerald-600 flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4 mr-1">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                        </svg>
                        Chép
                    </span>
                    ) : (
                    <>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4 mr-1.5">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M15.666 3.888A2.25 2.25 0 0013.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v0a.75.75 0 01-.75.75H9a.75.75 0 01-.75-.75v0c0-.212.03-.418.084-.612m7.332 0c.646.049 1.288.11 1.927.184 1.1.128 1.907 1.077 1.907 2.185V19.5a2.25 2.25 0 01-2.25 2.25H6.75A2.25 2.25 0 014.5 19.5V6.257c0-1.108.806-2.057 1.907-2.185a48.208 48.208 0 011.927-.184" />
                        </svg>
                        Copy
                    </>
                    )}
                </button>
               )}
            </div>
          </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-hidden relative bg-slate-100/50 p-4 md:p-8">
        {activeTab === 'preview' ? (
          <div className="h-full overflow-y-auto custom-scrollbar flex justify-center">
            <div 
              ref={previewRef}
              className="paper-sheet w-full max-w-[210mm] min-h-full bg-white text-slate-900 shadow-2xl p-[20mm] md:p-[25mm] rounded-2xl"
              dangerouslySetInnerHTML={{ __html: displayedHtml }} 
            />
          </div>
        ) : (
          <div className="h-full rounded-xl overflow-hidden shadow-inner border border-slate-300 relative">
             {/* Edit Status Indicator */}
             {!isEditable && (
                <div className="absolute top-2 right-4 bg-yellow-100 text-yellow-700 text-xs px-2 py-1 rounded-md border border-yellow-200 z-20 pointer-events-none flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3 h-3 mr-1">
                        <path fillRule="evenodd" d="M10 1a4.5 4.5 0 00-4.5 4.5V9H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-.5V5.5A4.5 4.5 0 0010 1zm3 8V5.5a3 3 0 10-6 0V9h6z" clipRule="evenodd" />
                    </svg>
                    Chế độ Chỉ đọc
                </div>
             )}
             <textarea
                readOnly={!isEditable}
                value={localLatexCode}
                onChange={(e) => setLocalLatexCode(e.target.value)}
                className={`w-full h-full bg-[#1e1e1e] text-[#d4d4d4] font-mono text-sm p-6 outline-none resize-none custom-scrollbar leading-relaxed ${!isEditable ? 'opacity-80' : ''}`}
                spellCheck={false}
                placeholder="Mã nguồn LaTeX sẽ hiển thị ở đây..."
            />
          </div>
        )}
      </div>

       {activeTab === 'preview' && (
        <div className="bg-white/60 backdrop-blur-sm p-2 text-[10px] text-slate-500 text-center border-t border-white/50">
          Chế độ xem trước hỗ trợ công thức toán học (KaTeX) và hình vẽ (SVG). Nhấn <b>Tải Word</b> để tải file về chỉnh sửa.
        </div>
      )}
      
      {/* Drawing Modal */}
      <DrawingModal 
        isOpen={isDrawingOpen}
        onClose={() => setIsDrawingOpen(false)}
        onSave={handleInsertDrawing}
      />
    </div>
  );
};

export default LatexPreview;