import React, { useState } from 'react';

interface LoginScreenProps {
  onLogin: (user: { email: string; name: string }) => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    // Giả lập gọi API kiểm tra đăng nhập
    setTimeout(() => {
      setIsLoading(false);
      
      // Admin account - Có quyền chỉnh sửa code
      if (email === 'daotam28@gmail.com' && password === '123456') {
        onLogin({
          email: email,
          name: 'Đào Tâm (Admin)' 
        });
      } 
      // Standard account - Chỉ có quyền xem (Read-only)
      else if (email === 'user@gmail.com' && password === '123456') {
        onLogin({
            email: email,
            name: 'Giáo viên (User)'
        });
      }
      else {
        setError("Tài khoản hoặc mật khẩu không chính xác.");
      }
    }, 1000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 p-4 font-sans">
      <div className="w-full max-w-md bg-white/70 backdrop-blur-xl border border-white/50 shadow-2xl rounded-3xl overflow-hidden animate-fade-in-up">
        
        {/* Header / Logo */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-8 text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-white/10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-30"></div>
          <div className="relative z-10 flex flex-col items-center">
             <div className="bg-white/20 p-3 rounded-2xl mb-4 shadow-inner backdrop-blur-sm">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="w-10 h-10 text-white"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M4.26 10.147a60.436 60.436 0 00-.491 6.347A48.627 48.627 0 0112 20.904a48.627 48.627 0 018.232-4.41 60.46 60.46 0 00-.491-6.347m-15.482 0a50.57 50.57 0 00-2.658-.8138.833 0 01-2.434 4.153h2.247l.869.2195a1 1 0 00.999-1.508l-1.678-4.412z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 3a6 6 0 100 12 6 6 0 000-12z"
                  />
                </svg>
             </div>
             <h1 className="text-3xl font-extrabold text-white tracking-tight">ExamGen Pro</h1>
             <p className="text-blue-100 text-sm mt-1">Hệ thống tạo đề thi thông minh bằng AI</p>
          </div>
        </div>

        {/* Form */}
        <div className="p-8">
          <h2 className="text-xl font-bold text-slate-800 mb-6 text-center">Đăng nhập hệ thống</h2>
          
          <form onSubmit={handleSubmit} className="space-y-5">
            {error && (
               <div className="p-3 bg-red-50 border border-red-100 text-red-600 text-sm rounded-xl flex items-center animate-pulse">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5 mr-2 shrink-0">
                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                  {error}
               </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">Email / Tài khoản</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5">
                    <path d="M3 4a2 2 0 00-2 2v1.161l8.441 4.221a1.25 1.25 0 001.118 0L19 7.162V6a2 2 0 00-2-2H3z" />
                    <path d="M19 8.839l-7.77 3.885a2.75 2.75 0 01-2.46 0L1 8.839V14a2 2 0 002 2h14a2 2 0 002-2V8.839z" />
                  </svg>
                </div>
                <input
                  type="email"
                  required
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all text-slate-800 font-medium"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">Mật khẩu</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5">
                    <path fillRule="evenodd" d="M10 1a4.5 4.5 0 00-4.5 4.5V9H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-.5V5.5A4.5 4.5 0 0010 1zm3 8V5.5a3 3 0 10-6 0V9h6z" clipRule="evenodd" />
                  </svg>
                </div>
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  className="w-full pl-10 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all text-slate-800 font-medium"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 transition-colors focus:outline-none"
                >
                  {showPassword ? (
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5">
                        <path d="M10 12.5a2.5 2.5 0 100-5 2.5 2.5 0 000 5z" />
                        <path fillRule="evenodd" d="M.664 10.59a1.651 1.651 0 010-1.186A10.004 10.004 0 0110 3c4.257 0 7.893 2.66 9.336 6.41.147.381.146.804 0 1.186A10.004 10.004 0 0110 17c-4.257 0-7.893-2.66-9.336-6.41zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5">
                      <path fillRule="evenodd" d="M3.28 2.22a.75.75 0 00-1.06 1.06l14.5 14.5a.75.75 0 101.06-1.06l-1.745-1.745A10.029 10.029 0 0019.336 10.59a1.651 1.651 0 000-1.186A10.004 10.004 0 0010 3c-4.257 0-7.893 2.66-9.336 6.41-.147.381-.146.804 0 1.186A10.015 10.015 0 005.403 14.535L3.28 2.22zm12.18 12.18l-3.23-3.23a2.5 2.5 0 10-3.46 3.46l3.23 3.23a4.01 4.01 0 01-3.23.14 10.002 10.002 0 01-9.336-6.41 10.015 10.015 0 013.88-4.42l1.62 1.62a4.01 4.01 0 005.42 5.42l1.62 1.62a10.015 10.015 0 01-4.42 3.88z" clipRule="evenodd" />
                      <path fillRule="evenodd" d="M14.86 10a4 4 0 00-5.72-5.72l5.72 5.72zm-2.09 2.09L9.64 8.96a2.5 2.5 0 003.13 3.13z" clipRule="evenodd" />
                    </svg>
                  )}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3.5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold rounded-xl shadow-lg shadow-blue-500/30 hover:shadow-blue-500/50 hover:scale-[1.02] active:scale-95 transition-all flex justify-center items-center"
            >
              {isLoading ? (
                <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              ) : (
                "Đăng nhập"
              )}
            </button>
          </form>

          <div className="mt-6 flex items-center justify-between">
            <span className="h-px w-full bg-slate-200"></span>
            <span className="px-3 text-xs text-slate-400 font-bold uppercase whitespace-nowrap">Hoặc</span>
            <span className="h-px w-full bg-slate-200"></span>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3">
             <button className="flex items-center justify-center py-2.5 border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors opacity-60 cursor-not-allowed" disabled>
                <img src="https://www.svgrepo.com/show/475656/google-color.svg" className="w-5 h-5 mr-2" alt="Google" />
                <span className="text-sm font-bold text-slate-600">Google</span>
             </button>
             <button className="flex items-center justify-center py-2.5 border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors opacity-60 cursor-not-allowed" disabled>
                <img src="https://www.svgrepo.com/show/475647/facebook-color.svg" className="w-5 h-5 mr-2" alt="Facebook" />
                <span className="text-sm font-bold text-slate-600">Facebook</span>
             </button>
          </div>

           <p className="mt-8 text-center text-sm text-slate-500">
            Hỗ trợ kỹ thuật: <span className="font-bold text-slate-600">0366.000.555</span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoginScreen;