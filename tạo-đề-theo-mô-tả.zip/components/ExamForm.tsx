import React, { useState, useRef, useEffect } from "react";
import {
  ExamConfig,
  Subject,
  Grade,
  ExamType,
  GenerationMode,
  DifficultyStructure,
  DifficultyLevel,
  UploadedFile,
  Structure7991
} from "../types";
import {
  SUBJECT_OPTIONS,
  GRADE_OPTIONS,
  EXAM_TYPE_OPTIONS,
  DIFFICULTY_OPTIONS,
  CURRICULUM_TOPICS,
  GENERIC_TOPICS
} from "../constants";

interface ExamFormProps {
  config: ExamConfig;
  setConfig: (config: ExamConfig) => void;
  isLoading: boolean;
  progress?: { current: number; total: number } | null;
  hasResults?: boolean;
  onSubmit: () => void;
  onCancel: () => void;
  onClear?: () => void;
}

const ExamForm: React.FC<ExamFormProps> = ({
  config,
  setConfig,
  isLoading,
  progress,
  hasResults,
  onSubmit,
  onCancel,
  onClear,
}) => {
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const matrixInputRef = useRef<HTMLInputElement>(null);
  const referenceInputRef = useRef<HTMLInputElement>(null);

  // Load available topics based on subject and grade
  const [availableTopics, setAvailableTopics] = useState<string[]>([]);

  useEffect(() => {
    // Reset selected topics when subject or grade changes
    handleChange("selectedTopics", []);

    const subjectData = CURRICULUM_TOPICS[config.subject];
    if (subjectData && subjectData[config.grade]) {
        setAvailableTopics(subjectData[config.grade]);
    } else {
        setAvailableTopics(GENERIC_TOPICS);
    }
  }, [config.subject, config.grade]);

  const handleChange = <K extends keyof ExamConfig>(
    key: K,
    value: ExamConfig[K]
  ) => {
    setConfig({ ...config, [key]: value });
  };

  const handleTopicToggle = (topic: string) => {
      const currentTopics = config.selectedTopics || [];
      if (currentTopics.includes(topic)) {
          handleChange("selectedTopics", currentTopics.filter(t => t !== topic));
      } else {
          handleChange("selectedTopics", [...currentTopics, topic]);
      }
  };

  const handleStructureChange = (
    key: keyof DifficultyStructure,
    value: string
  ) => {
    const numValue = parseInt(value, 10) || 0;
    setConfig({
      ...config,
      structure: { ...config.structure, [key]: numValue },
    });
  };

  const handleStructure7991Change = (
    key: keyof Structure7991,
    value: string
  ) => {
    const numValue = parseInt(value, 10) || 0;
    setConfig({
        ...config,
        structure7991: { ...config.structure7991, [key]: numValue }
    });
  };

  // Helper to get suggestions based on subject
  const getSubjectSuggestions = (subject: Subject): string[] => {
    switch (subject) {
      case Subject.MATH:
        return [
          "Tập trung vào tính đơn điệu và cực trị, có bài toán thực tế.",
          "Bài toán lãi suất ngân hàng và tối ưu hóa.",
          "Hình học: Tính khoảng cách và góc trong không gian."
        ];
      case Subject.LITERATURE:
        return [
          "Phân tích giá trị nhân đạo.",
          "Nghị luận về trách nhiệm của tuổi trẻ.",
        ];
      case Subject.ENGLISH:
        return [
          "Chủ đề: Daily Life.",
          "Câu điều kiện loại 1, 2 và câu bị động.",
          "Reading passage về chủ đề Environment."
        ];
      case Subject.PHYSICS:
        return [
          "Con lắc lò xo và bài toán năng lượng.",
          "Mạch RLC nối tiếp và công suất tiêu thụ."
        ];
      case Subject.CHEMISTRY:
        return [
          "Bài tập đốt cháy Este.",
          "Nhận biết các chất vô cơ."
        ];
      default:
        return [
          "Đề thi bám sát cấu trúc đề minh họa.",
          "Tập trung vào các câu hỏi vận dụng thực tiễn."
        ];
    }
  };

  const suggestions = getSubjectSuggestions(config.subject);

  // Generic file processor
  const processFileGeneric = (file: File, targetField: 'uploadedFile' | 'matrixFile' | 'referenceFile') => {
    const validTypes = ['application/pdf', 'image/png', 'image/jpeg', 'image/webp', 'text/plain', 'text/markdown'];
    const validExts = ['.tex', '.txt', '.md'];
    
    const isNameValid = validExts.some(ext => file.name.endsWith(ext));
    const isTypeValid = validTypes.includes(file.type);

    if (!isTypeValid && !isNameValid) {
        alert("Chỉ hỗ trợ file PDF, Ảnh (PNG, JPG), hoặc văn bản (TXT, TEX, MD)");
        return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
        const result = event.target?.result as string;
        
        // Special handling for 'uploadedFile' (Sample Exam) text content extraction
        if (targetField === 'uploadedFile' && (file.type.startsWith('text/') || file.name.endsWith('.tex') || file.name.endsWith('.md') || file.name.endsWith('.txt'))) {
             handleChange("sampleContent", result);
             handleChange("uploadedFile", null);
        } else {
             // Default binary/base64 handling for all fields (images, PDFs)
             const base64Data = result.split(',')[1];
             const uploadObj: UploadedFile = {
                 data: base64Data,
                 mimeType: file.type,
                 fileName: file.name
             };
             handleChange(targetField, uploadObj);
        }
    };

    if (file.type.startsWith('text/') || file.name.endsWith('.tex') || file.name.endsWith('.md') || file.name.endsWith('.txt')) {
        reader.readAsText(file);
    } else {
        reader.readAsDataURL(file);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFileGeneric(e.dataTransfer.files[0], 'uploadedFile');
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
      if (config.mode !== GenerationMode.SAMPLE) return;

      if (e.clipboardData.files && e.clipboardData.files.length > 0) {
          e.preventDefault();
          processFileGeneric(e.clipboardData.files[0], 'uploadedFile');
      }
  };
  
  const removeFile = (field: 'uploadedFile' | 'matrixFile' | 'referenceFile') => {
      handleChange(field, null);
      // Reset input values
      if (field === 'uploadedFile' && fileInputRef.current) fileInputRef.current.value = "";
      if (field === 'matrixFile' && matrixInputRef.current) matrixInputRef.current.value = "";
      if (field === 'referenceFile' && referenceInputRef.current) referenceInputRef.current.value = "";
  };

  // Helper styles for inputs
  const inputClass = "w-full rounded-xl border-slate-200 border bg-slate-50/50 p-2.5 text-sm transition-all focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none shadow-sm hover:border-blue-300";
  const labelClass = "block text-xs font-bold text-slate-600 mb-1.5 uppercase tracking-wide";

  // Reusable File Upload Component
  const SmallFileUpload = ({ 
    label, 
    file, 
    inputRef, 
    field 
  }: { 
    label: string, 
    file: UploadedFile | null, 
    inputRef: React.RefObject<HTMLInputElement | null>, // Adjusted type definition
    field: 'matrixFile' | 'referenceFile' 
  }) => (
    <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm">
        <label className="block text-[10px] font-bold text-slate-500 uppercase mb-2">{label}</label>
        <input 
            ref={inputRef}
            type="file" 
            accept="image/*,application/pdf,.txt,.tex,.md"
            className="hidden"
            onChange={(e) => {
                if (e.target.files?.[0]) processFileGeneric(e.target.files[0], field);
            }}
        />
        {!file ? (
            <button 
                type="button"
                onClick={() => inputRef.current?.click()}
                className="w-full py-2 border border-dashed border-slate-300 rounded-lg text-xs text-slate-500 hover:bg-slate-50 hover:border-blue-400 hover:text-blue-600 transition-all flex items-center justify-center space-x-1"
            >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-3 h-3">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                </svg>
                <span>Thêm File</span>
            </button>
        ) : (
            <div className="flex items-center justify-between bg-blue-50 p-2 rounded-md border border-blue-100">
                <div className="flex items-center space-x-2 overflow-hidden">
                    <div className="flex-shrink-0 text-blue-500">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4">
                            <path fillRule="evenodd" d="M4.5 2A1.5 1.5 0 003 3.5v13A1.5 1.5 0 004.5 18h11a1.5 1.5 0 001.5-1.5V7.621a1.5 1.5 0 00-.44-1.06l-4.12-4.122A1.5 1.5 0 0011.378 2H4.5zm2.25 8.5a.75.75 0 000 1.5h6.5a.75.75 0 000-1.5h-6.5zm0 3a.75.75 0 000 1.5h6.5a.75.75 0 000-1.5h-6.5z" clipRule="evenodd" />
                        </svg>
                    </div>
                    <span className="text-xs font-medium text-blue-900 truncate max-w-[120px]" title={file.fileName}>{file.fileName}</span>
                </div>
                <button onClick={() => removeFile(field)} className="text-slate-400 hover:text-red-500">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4">
                        <path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z" />
                    </svg>
                </button>
            </div>
        )}
    </div>
  );

  return (
    <div className="h-full flex flex-col p-6 space-y-6 overflow-y-auto custom-scrollbar" onPaste={handlePaste}>
      <div>
        <h2 className="text-2xl font-black text-slate-800 mb-1 tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-slate-700">Cấu hình đề thi</h2>
        <p className="text-sm text-slate-500 font-medium">
          Chọn thông số để AI tạo đề phù hợp nhất.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Subject */}
        <div>
          <label className={labelClass}>Môn học (GDPT 2018)</label>
          <div className="relative">
             <select
                className={`${inputClass} appearance-none cursor-pointer`}
                value={config.subject}
                onChange={(e) => handleChange("subject", e.target.value as Subject)}
            >
                {SUBJECT_OPTIONS.map((sub) => (
                <option key={sub} value={sub}>{sub}</option>
                ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-500">
                <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
            </div>
          </div>
        </div>

        {/* Grade */}
        <div>
          <label className={labelClass}>Lớp / Trình độ</label>
          <div className="relative">
            <select
                className={`${inputClass} appearance-none cursor-pointer`}
                value={config.grade}
                onChange={(e) => handleChange("grade", e.target.value as Grade)}
            >
                {GRADE_OPTIONS.map((g) => (
                <option key={g} value={g}>{g}</option>
                ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-500">
                <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
            </div>
          </div>
        </div>

        {/* Exam Type */}
        <div className="md:col-span-2">
          <label className={labelClass}>Loại kiểm tra</label>
          <div className="relative">
            <select
                className={`${inputClass} appearance-none cursor-pointer`}
                value={config.examType}
                onChange={(e) =>
                handleChange("examType", e.target.value as ExamType)
                }
            >
                {EXAM_TYPE_OPTIONS.map((t) => (
                <option key={t} value={t}>{t}</option>
                ))}
            </select>
             <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-500">
                <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
            </div>
          </div>
        </div>

        {/* Difficulty Level */}
        <div className="md:col-span-2">
          <label className={labelClass}>Mức độ khó</label>
          <div className="grid grid-cols-3 gap-2 bg-slate-100 p-1 rounded-xl">
            {DIFFICULTY_OPTIONS.map((level) => (
                <button
                    key={level}
                    type="button"
                    onClick={() => handleChange("difficultyLevel", level)}
                    className={`py-2 px-1 text-xs font-semibold rounded-lg transition-all shadow-sm ${
                        config.difficultyLevel === level
                        ? "bg-white text-indigo-600 shadow-md ring-1 ring-black/5 scale-[1.02]"
                        : "bg-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-200/50"
                    }`}
                >
                    {level}
                </button>
            ))}
          </div>
        </div>

         {/* Knowledge Content Selection */}
         <div className="md:col-span-2 animate-fade-in-up">
            <label className={labelClass}>Nội dung kiến thức / Chương bài</label>
            <div className="bg-white border border-slate-200 rounded-xl max-h-48 overflow-y-auto custom-scrollbar p-1">
                {availableTopics.length > 0 ? (
                    <div className="grid grid-cols-1 gap-1">
                        {availableTopics.map((topic, index) => (
                            <label 
                                key={index} 
                                className={`flex items-start p-2 rounded-lg cursor-pointer transition-colors ${
                                    config.selectedTopics.includes(topic) 
                                    ? "bg-blue-50/70" 
                                    : "hover:bg-slate-50"
                                }`}
                            >
                                <div className="flex h-5 items-center">
                                    <input
                                        type="checkbox"
                                        className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                                        checked={config.selectedTopics.includes(topic)}
                                        onChange={() => handleTopicToggle(topic)}
                                    />
                                </div>
                                <div className="ml-3 text-xs leading-5">
                                    <span className={`${config.selectedTopics.includes(topic) ? "text-blue-700 font-semibold" : "text-slate-700"}`}>
                                        {topic}
                                    </span>
                                </div>
                            </label>
                        ))}
                    </div>
                ) : (
                    <p className="p-4 text-center text-xs text-slate-400">Không có dữ liệu chương trình cho môn học này.</p>
                )}
            </div>
             <p className="text-[10px] text-slate-400 mt-1.5 flex justify-between">
                <span>Đã chọn: {config.selectedTopics.length} nội dung</span>
                {config.selectedTopics.length > 0 && (
                     <button 
                        type="button" 
                        onClick={() => handleChange("selectedTopics", [])}
                        className="text-red-500 hover:underline"
                    >
                        Bỏ chọn tất cả
                    </button>
                )}
            </p>
         </div>

         {/* Number of Variants */}
         <div className="md:col-span-2">
            <div className="flex justify-between items-center mb-2">
                <label className={labelClass.replace("mb-1.5", "mb-0")}>Số lượng mã đề</label>
                <span className="text-xs font-bold text-white bg-blue-500 px-2 py-0.5 rounded-full shadow-sm shadow-blue-500/30">
                    {config.numberOfVariants}
                </span>
            </div>
            <input 
                type="range" 
                min="1" 
                max="5" 
                step="1"
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                value={config.numberOfVariants}
                onChange={(e) => handleChange("numberOfVariants", parseInt(e.target.value))}
            />
             <div className="flex justify-between text-[10px] text-slate-400 font-medium px-1 mt-1">
                <span>1 đề</span>
                <span>5 đề</span>
            </div>
        </div>
      </div>

      <div className="border-t border-slate-200/60 pt-6">
        <label className={labelClass}>Phương thức tạo nội dung</label>
        <div className="flex flex-wrap gap-2 mb-4">
            {[GenerationMode.DESCRIPTION, GenerationMode.STRUCTURE, GenerationMode.SAMPLE, GenerationMode.OFFICIAL_7991].map(mode => (
                <button
                    key={mode}
                    type="button"
                    onClick={() => handleChange("mode", mode)}
                    className={`flex-1 py-2.5 px-2 text-[11px] md:text-xs font-bold rounded-xl border transition-all whitespace-nowrap ${
                    config.mode === mode
                        ? "bg-blue-50 border-blue-500 text-blue-700 ring-1 ring-blue-500/20"
                        : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50 hover:border-slate-300"
                    }`}
                >
                    {mode === GenerationMode.DESCRIPTION && "Theo Mô Tả"}
                    {mode === GenerationMode.STRUCTURE && "Theo Cấu Trúc"}
                    {mode === GenerationMode.SAMPLE && "Theo Đề Mẫu"}
                    {mode === GenerationMode.OFFICIAL_7991 && "CV 7991"}
                </button>
            ))}
        </div>

        {config.mode === GenerationMode.DESCRIPTION && (
          <div className="animate-fade-in-up">
            <textarea
              className={`${inputClass} h-32 resize-none leading-relaxed`}
              placeholder="Nhập mô tả chi tiết bổ sung (nếu có)..."
              value={config.description}
              onChange={(e) => handleChange("description", e.target.value)}
            />
            {/* Intelligent Suggestions */}
            <div className="mt-3 flex flex-wrap gap-2">
                {suggestions.map((text, idx) => (
                    <button
                        key={idx}
                        type="button"
                        onClick={() => handleChange("description", text)}
                        className="text-[10px] px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-500 hover:border-blue-400 hover:text-blue-600 hover:shadow-sm transition-all text-left flex items-center"
                    >
                        <span className="mr-1 opacity-50">+</span> {text}
                    </button>
                ))}
            </div>
          </div>
        )}

        {config.mode === GenerationMode.STRUCTURE && (
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 animate-fade-in-up">
            <p className="text-xs text-slate-500 mb-3 font-medium">
              Nhập số lượng câu hỏi cho mỗi mức độ khó.
            </p>
            <div className="grid grid-cols-2 gap-4">
              {[
                { label: "Nhận biết (Dễ)", key: "easy", color: "text-green-600" },
                { label: "Thông hiểu (TB)", key: "medium", color: "text-blue-600" },
                { label: "Vận dụng (Khó)", key: "hard", color: "text-orange-600" },
                { label: "Vận dụng cao", key: "veryHard", color: "text-red-600" }
              ].map((item) => (
                  <div key={item.key}>
                    <label className={`block text-[10px] font-bold ${item.color} mb-1 uppercase`}>
                      {item.label}
                    </label>
                    <input
                      type="number"
                      min="0"
                      className={inputClass}
                      value={config.structure[item.key as keyof DifficultyStructure]}
                      onChange={(e) => handleStructureChange(item.key as keyof DifficultyStructure, e.target.value)}
                    />
                  </div>
              ))}
            </div>
          </div>
        )}

        {config.mode === GenerationMode.OFFICIAL_7991 && (
            <div className="animate-fade-in-up space-y-3">
                <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-100">
                    <h3 className="text-sm font-bold text-indigo-800 mb-3 flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 mr-1">
                            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                        </svg>
                        Cấu hình số lượng câu hỏi (Theo CV 7991):
                    </h3>
                    
                    <div className="grid grid-cols-2 gap-3 mb-3">
                         <div>
                            <label className="block text-[10px] font-bold text-indigo-700 mb-1 uppercase">
                                I. Trắc nghiệm (Câu)
                            </label>
                            <input
                                type="number"
                                min="0"
                                className={`${inputClass} border-indigo-200 focus:border-indigo-400`}
                                value={config.structure7991.part1}
                                onChange={(e) => handleStructure7991Change("part1", e.target.value)}
                            />
                        </div>
                        <div>
                            <label className="block text-[10px] font-bold text-indigo-700 mb-1 uppercase">
                                II. Đúng/Sai (Câu)
                            </label>
                            <input
                                type="number"
                                min="0"
                                className={`${inputClass} border-indigo-200 focus:border-indigo-400`}
                                value={config.structure7991.part2}
                                onChange={(e) => handleStructure7991Change("part2", e.target.value)}
                            />
                        </div>
                         <div>
                            <label className="block text-[10px] font-bold text-indigo-700 mb-1 uppercase">
                                III. Trả lời ngắn (Câu)
                            </label>
                            <input
                                type="number"
                                min="0"
                                className={`${inputClass} border-indigo-200 focus:border-indigo-400`}
                                value={config.structure7991.part3}
                                onChange={(e) => handleStructure7991Change("part3", e.target.value)}
                            />
                        </div>
                         <div>
                            <label className="block text-[10px] font-bold text-indigo-700 mb-1 uppercase">
                                IV. Tự luận (Câu)
                            </label>
                            <input
                                type="number"
                                min="0"
                                className={`${inputClass} border-indigo-200 focus:border-indigo-400`}
                                value={config.structure7991.part4}
                                onChange={(e) => handleStructure7991Change("part4", e.target.value)}
                            />
                        </div>
                    </div>
                    <p className="text-[10px] text-indigo-500 italic">
                        * Mặc định: 12 câu TN, 2 câu Đ/S, 4 câu TLN, 3 câu Tự luận.
                    </p>
                </div>
                <div>
                     <label className={labelClass}>Chủ đề nội dung bổ sung</label>
                     <textarea
                        className={`${inputClass} h-24 resize-none leading-relaxed`}
                        placeholder="Nhập nội dung kiến thức muốn kiểm tra (Ví dụ: Hàm số, Tích phân...)"
                        value={config.description}
                        onChange={(e) => handleChange("description", e.target.value)}
                    />
                </div>
            </div>
        )}

        {config.mode === GenerationMode.SAMPLE && (
            <div className="space-y-3 animate-fade-in-up">
                
                {/* Drag and Drop Area */}
                <div 
                    className={`relative border-2 border-dashed rounded-xl p-6 flex flex-col items-center justify-center text-center transition-all duration-300 group ${
                        dragActive 
                        ? "border-blue-500 bg-blue-50 scale-[0.99]" 
                        : "border-slate-300 bg-slate-50 hover:bg-white hover:border-blue-400 hover:shadow-md"
                    }`}
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                >
                    <input 
                        ref={fileInputRef}
                        type="file" 
                        accept="image/*,application/pdf,.txt,.tex,.md"
                        capture="environment" 
                        className="hidden"
                        onChange={(e) => {
                             if (e.target.files?.[0]) processFileGeneric(e.target.files[0], 'uploadedFile');
                        }}
                    />
                    
                    {!config.uploadedFile ? (
                        <>
                            <div className="bg-white p-3 rounded-full shadow-sm mb-3 group-hover:scale-110 transition-transform text-blue-500">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M6.827 6.175A2.31 2.31 0 015.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 00-1.134-.175 2.31 2.31 0 01-1.64-1.055l-.822-1.316a2.192 2.192 0 00-1.736-1.039 48.774 48.774 0 00-5.232 0 2.192 2.192 0 00-1.736 1.039l-.821 1.316z" />
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 12.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0zM18.75 10.5h.008v.008h-.008V10.5z" />
                                </svg>
                            </div>
                            <p className="text-sm text-slate-700 font-bold mb-1">Tải lên đề mẫu</p>
                            <p className="text-xs text-slate-400 mb-3 px-4">Hỗ trợ: Ảnh chụp đề thi, PDF, Word, hoặc file Text</p>
                            <button 
                                type="button"
                                onClick={() => fileInputRef.current?.click()}
                                className="flex items-center space-x-2 text-xs bg-blue-600 text-white px-5 py-2 rounded-full shadow-lg shadow-blue-600/20 hover:bg-blue-700 transition-colors font-bold"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
                                </svg>
                                <span>Tải ảnh / PDF</span>
                            </button>
                        </>
                    ) : (
                        <div className="w-full flex items-center justify-between bg-white p-3 rounded-lg border border-blue-100 shadow-sm relative overflow-hidden group/file">
                             <div className="flex items-center space-x-3 overflow-hidden z-10 relative">
                                <div className="bg-blue-50 p-1 rounded-lg border border-blue-100 flex-shrink-0 w-12 h-12 flex items-center justify-center overflow-hidden">
                                    {config.uploadedFile.mimeType.startsWith('image/') ? (
                                        <img 
                                            src={`data:${config.uploadedFile.mimeType};base64,${config.uploadedFile.data}`} 
                                            alt="Preview" 
                                            className="w-full h-full object-cover rounded-md"
                                        />
                                    ) : config.uploadedFile.mimeType.includes('pdf') ? (
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8 text-red-500">
                                            <path fillRule="evenodd" d="M5.625 1.5c-1.036 0-1.875.84-1.875 1.875v17.25c0 1.035.84 1.875 1.875 1.875h12.75c1.035 0 1.875-.84 1.875-1.875V12.75A3.75 3.75 0 0016.5 9h-1.875a1.875 1.875 0 01-1.875-1.875V5.25A3.75 3.75 0 009 1.5H5.625zM7.5 15a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5A.75.75 0 017.5 15zm.75 2.25a.75.75 0 000 1.5H12a.75.75 0 000-1.5H8.25z" clipRule="evenodd" />
                                            <path d="M12.971 1.816A5.23 5.23 0 0114.25 5.25v1.875c0 .207.168.375.375.375H16.5a5.23 5.23 0 013.434 1.279 9.768 9.768 0 00-6.963-6.963z" />
                                        </svg>
                                    ) : (
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8 text-slate-500">
                                             <path fillRule="evenodd" d="M3 4.875C3 3.839 3.84 3 4.875 3h4.5c1.035 0 1.875.84 1.875 1.875v17.25c0 1.035-.84 1.875-1.875 1.875h-4.5A1.875 1.875 0 013 22.125V4.875zM8.25 9a.75.75 0 01.75.75v2.25a.75.75 0 01-1.5 0v-2.25A.75.75 0 018.25 9zM6 9a.75.75 0 01.75.75v2.25a.75.75 0 01-1.5 0v-2.25A.75.75 0 016 9z" clipRule="evenodd" />
                                             <path fillRule="evenodd" d="M12.75 3a.75.75 0 01.75-.75h4.5a.75.75 0 01.75.75v19.5a.75.75 0 01-.75.75h-4.5a.75.75 0 01-.75-.75V3zm2.25 6a.75.75 0 01.75.75v2.25a.75.75 0 01-1.5 0v-2.25a.75.75 0 01.75-.75zm0 9a.75.75 0 01.75.75v2.25a.75.75 0 01-1.5 0v-2.25a.75.75 0 01.75-.75z" clipRule="evenodd" />
                                        </svg>
                                    )}
                                </div>
                                <div className="flex flex-col min-w-0 text-left">
                                    <span className="text-sm font-bold text-slate-800 truncate">{config.uploadedFile.fileName}</span>
                                    <span className="text-[10px] text-slate-400 truncate uppercase tracking-wider">{config.uploadedFile.mimeType.split('/')[1] || 'FILE'}</span>
                                </div>
                             </div>
                             <button onClick={() => removeFile('uploadedFile')} className="z-10 text-slate-400 hover:text-red-500 p-2 hover:bg-red-50 rounded-lg transition-colors" title="Xóa file">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5">
                                  <path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z" />
                                </svg>
                             </button>
                        </div>
                    )}
                </div>

                <textarea
                    className={`${inputClass} h-20 resize-none`}
                    placeholder="Ghi chú thêm cho AI (VD: Lấy các câu hình học trong ảnh, bỏ câu đại số...)"
                    value={config.sampleContent}
                    onChange={(e) => handleChange("sampleContent", e.target.value)}
                />
            </div>
        )}
      </div>

      {/* Supplementary Materials Section */}
      <div className="border-t border-slate-200/60 pt-6">
         <details className="group rounded-xl border border-slate-200 bg-slate-50 open:bg-white open:shadow-sm transition-all duration-300">
            <summary className="flex cursor-pointer items-center justify-between p-4 font-bold text-slate-700 hover:bg-slate-100/50 rounded-xl transition-colors">
                <span className="flex items-center space-x-2">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-indigo-500">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
                    </svg>
                    <span>Tài liệu bổ trợ</span>
                </span>
                <span className="transition group-open:rotate-180">
                    <svg fill="none" height="20" shapeRendering="geometricPrecision" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" viewBox="0 0 24 24" width="20"><path d="M6 9l6 6 6-6"></path></svg>
                </span>
            </summary>
            <div className="px-4 pb-4 animate-fade-in text-sm text-slate-500">
                <p className="mb-3">Tải lên Ma trận đề thi hoặc Tài liệu/Sách giáo khoa để AI ra đề sát với chương trình học.</p>
                <div className="grid grid-cols-2 gap-3">
                    <SmallFileUpload 
                        label="Ma trận / Đặc tả" 
                        file={config.matrixFile} 
                        inputRef={matrixInputRef}
                        field="matrixFile"
                    />
                    <SmallFileUpload 
                        label="Tài liệu / Sách GK" 
                        file={config.referenceFile} 
                        inputRef={referenceInputRef}
                        field="referenceFile"
                    />
                </div>
            </div>
         </details>
      </div>

      <div className="flex-1"></div>

      <div className="sticky bottom-0 bg-white/95 backdrop-blur border-t border-slate-200 p-4 -mx-6 -mb-6 mt-4 z-20 shadow-[0_-4px_10px_rgba(0,0,0,0.05)]">
        <div className="flex space-x-3">
        {isLoading ? (
          <>
             <button
              onClick={onSubmit}
              disabled={true}
              className="flex-1 py-3.5 px-4 rounded-xl text-white font-bold shadow-lg shadow-blue-500/30 bg-gradient-to-r from-blue-500 to-indigo-500 cursor-not-allowed flex items-center justify-center space-x-3 animate-pulse"
            >
               <div className="relative">
                   <div className="absolute inset-0 bg-white/20 rounded-full animate-ping"></div>
                   <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 relative z-10 animate-bounce">
                        <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z" />
                    </svg>
               </div>
                <span className="text-sm">
                    {progress 
                        ? `Đang viết đề ${progress.current}/${progress.total}...` 
                        : `AI đang suy nghĩ...`}
                </span>
            </button>
            <button 
              onClick={onCancel}
              className="px-4 rounded-xl bg-white border border-red-200 text-red-500 font-bold hover:bg-red-50 transition-colors shadow-sm"
            >
              Hủy
            </button>
          </>
        ) : (
          <div className="flex space-x-2 w-full">
            {hasResults && onClear && (
               <button
                onClick={onClear}
                className="px-4 py-3 rounded-xl text-slate-500 bg-white border border-slate-200 font-bold shadow-sm hover:bg-slate-50 hover:text-slate-700 hover:border-slate-300 transition-all active:scale-95"
                title="Xóa kết quả hiện tại"
              >
                 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
                 </svg>
              </button>
            )}
            <button
              onClick={onSubmit}
              className="group flex-1 py-3.5 px-4 rounded-xl text-white font-bold shadow-lg shadow-blue-500/30 transition-all transform active:scale-95 flex items-center justify-center space-x-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 hover:shadow-blue-500/50"
            >
               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 group-hover:animate-bounce">
                    <path fillRule="evenodd" d="M9 4.5a.75.75 0 01.721.544l.813 2.846a3.75 3.75 0 002.576 2.576l2.846.813a.75.75 0 010 1.442l-2.846.813a3.75 3.75 0 00-2.576 2.576l-.813 2.846a.75.75 0 01-1.442 0l-.813-2.846a3.75 3.75 0 00-2.576-2.576l-2.846-.813a.75.75 0 010-1.442l2.846-.813a3.75 3.75 0 002.576-2.576l.813-2.846A.75.75 0 019 4.5zM18 1.5a.75.75 0 01.728.568l.258 1.036c.236.94.97 1.674 1.91 1.91l1.036.258a.75.75 0 010 1.456l-1.036.258c-.94.236-1.674.97-1.91 1.91l-.258 1.036a.75.75 0 01-1.456 0l-.258-1.036a2.625 2.625 0 00-1.91-1.91l-1.036-.258a.75.75 0 010-1.456l1.036-.258a2.625 2.625 0 001.91-1.91l.258-1.036A.75.75 0 0118 1.5zM16.5 15a.75.75 0 01.712.513l.394 1.183c.15.447.5.799.948.948l1.183.394a.75.75 0 010 1.422l-1.183.394c-.447.15-.799.5-.948.948l-.394 1.183a.75.75 0 01-1.422 0l-.394-1.183a1.5 1.5 0 00-.948-.948l-1.183-.394a.75.75 0 010-1.422l1.183-.394c.447-.15.799-.5.948-.948l.394-1.183A.75.75 0 0116.5 15z" clipRule="evenodd" />
               </svg>
              <span>Tạo {config.numberOfVariants} Đề</span>
            </button>
          </div>
        )}
        </div>
      </div>
    </div>
  );
};

export default ExamForm;